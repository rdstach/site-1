# valpin
> Validasi pinjaman

Dari dokumen yang telah aku terima, telah aku analisis dan jabarkan menjadi beberapa fitur, yang akan aku jelaskan dibawah.

Karena script memakai `process.cwd()`, kita perlu menjalan command-command dibawah dari direktori root, dan bukan dari direktori `src/`.

Untuk memulai memakai projek ini, ketik `node src/create_day_max 50 && yarn test`.

Sidenote: jika ingin menghapus / mengatur ulang databasenya, buang file JSON hari ini (layaknya `250620.json`) dan reset semua file json lainnya (accepted.json, installments.json, rejected.json, statuses.json) dan isi kontennya dengan hanya satu objek JavaScript (`{}`).

## Running

To run the code with Docker, you can simply build the image using `docker build`.
However to run it, you will need to run it with tty and sh enabled.

In this case, we will use drepram/valpin as our package name.

```
$ docker build -t drepram/valpin .
$ docker run -t -i drepram/valpin /bin/sh
```

## Example Usage

We need to define maxRequests, and add 2 loan applications for the app to function correctly:

```
$ ./create_day_max "50"
$ ./add "3174096112900001" "Seseorang" "5000000"
$ ./add "3172020903040069" "AndrePramaditya" "5000000"
```

And to test the whole features, feel free to run the commands below:

```
$ ./status 25062001
$ ./installment 26062001 "3" "3174096112900001"
$ ./find_by_amount_accepted 5000000 260620
$ ./find_by_amount_rejected 1000000 260620
```

---

### create_day_max [maximum]

This would create a JSON file with the format DD/MM/YY.json, and add maximum request and amount of loan applications as a property at the root of the file.

This endpoint has a default value of 50, if the variable is not present in the command line argument.

##### Code sample
```
$ create_day_max 50
```

### add [nik] [name] [amount] 

Insert loan application to database from the given arguments.<br>
Returns the loan application ID.

_This part got me pretty interested when I analyzed it because I thought I'm going to work with NIK again, and I wasn't wrong. This is a bit of one the core features of this project._

##### Code sample
```
$ add 3102020109900001 FahriKumala 5000000
```

### status [loanApplicationId]

Shows a loan application status.

_This feature is the simplest part of this project, all three features below this were built with keeping in mind the design that I've applied to this feature._

##### Code sample
```
$ status 25062001
```

### installment [loanApplicationId] [monthDuration] [nik]

Computes the plan for a loan with respect to the duration of the month.

_I was a bit confused with the graph that was presented on the test, so I asked friends and a family member to help me figure it out. Once I got it figured, I wrote the calculations into the script and that was the first MVP of it. Not long after this, I figured that the installment plans should probably be stored into JSON file, just like the others._

##### Code sample
```
$ installment 25062001 03 3102020109900001
```

### find_by_amount_accepted [moneyAmount] [today]

Filters out the loan applications that has been accepted with respect to the amount of money.

_Both of these features (find_by_amount_accepted & find_by_amount_rejected) are probably just has a little bit more functionality than the status feature. What it does is simply filtering out either the `find_by_amount_accepted.js` or `find_by_amount_rejected.js` for the queried transactions. After its done filtering out, it would increment the madeRequests in the main JSON file (`[date].json` / `250620.json`), just like the other features._

##### Code sample
```
$ find_by_amount_accepted 5000000 250620
```

### find_by_amount_rejected [moneyAmount] [today]

Filters out the loan applications that has been rejected with respect to the amount of money.

##### Code sample
```
$ find_by_amount_rejected 10000000 250620
```