const fs = require('fs')

function createInitialFile(max) {
  const maxRequests = Number(max) ? Number(max) : 50 // Default value if not given

  // Courtesy of https://stackoverflow.com/a/4929629/10103199
  let today = new Date()
  const day = String(today.getDate()).padStart(2, '0')
  const month = String(today.getMonth() + 1).padStart(2, '0') // January is 0
  const year = String(today.getFullYear()).slice(2) // Modification here, instead of using 4 digit years, we can just take the last 2 digit. Hence, the slice() method.

  today = day + month + year // Redefining the today variable with the necessary content

  const path = `${process.cwd()}/db/${today}.json`

  const content = {
    maxRequests,
    amountOfLoanApplications: 0, // defaults at 0
    requestsMade: 0 // defaults at 0
  }

  if (!(fs.existsSync(path))) {
    fs.writeFile(path, JSON.stringify(content), (err) => { // It writes the content (which we have to stringify into JSON) into the path.
      if (err) throw err
    })
    return `Succesfully created starter document, maximum request limit for date ${today} (max: ${maxRequests}) has been written into ${path}, please move on to the loan input steps.`
  } else {
    console.log(`Unable to recreate file on same date. Maximum requests limit (${maxRequests}) for loan application has been set for today (${path}).`)
    return false
  }
}

console.log(createInitialFile(process.argv[2]))

module.exports = createInitialFile