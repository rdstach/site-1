const fs = require('fs')

function getLoanApplicationStatus (loanApplicationId) {
  const genesisPath = `${process.cwd()}/db/${String(loanApplicationId).slice(0, String(loanApplicationId).length - 2)}.json` // Removing the last two digits
  const path = `${process.cwd()}/db/statuses.json`

  let genesisDb = JSON.parse(fs.readFileSync(genesisPath, 'utf8'))
  const selfDb = JSON.parse(fs.readFileSync(path, 'utf8'))

  if (genesisDb.requestsMade >= genesisDb.maxRequests) throw new Error('Maximum request limit has been reached')
  genesisDb.requestsMade++ // Increment it

  genesisDb = JSON.stringify(genesisDb) // Converts it back

  fs.writeFileSync(genesisPath, genesisDb, (err) => { // Returns it
    if (err) throw err
  })

  const selfDbRoot = selfDb.root.find(loanApps => String(loanApps.id) === String(loanApplicationId))

  if (!(selfDb.root === undefined || selfDb.root.length == 0)) {
    console.log(`Loan ID: ${selfDbRoot.id} is ${selfDbRoot.status ? 'accepted' : 'rejected'}`)
    return true
  } else {
    console.log(`Unable to fetch the following (${loanApplicationId}) loan application`)
    return false
  }
}

if (process.argv.length >= 3) console.log(getLoanApplicationStatus(process.argv[2]))

module.exports = getLoanApplicationStatus