const fs = require('fs')

function computeInstallment(date, duration, nik, unixTimestamp = Date.now()) {
  const genesisPath = `${process.cwd()}/db/${String(date).slice(0, String(date).length - 2)}.json`
  // '12091901'.slice(0, '12091901'.length-2) would return '120919' by removing the last two digits.
  // I must say the code is not slick, though it is shorter than the alternative I've thought in my head.
  const installmentPath = `${process.cwd()}/db/installments.json`
  const path = `${process.cwd()}/db/accepted.json`

  let genesisDb = JSON.parse(fs.readFileSync(genesisPath, 'utf8'))
  let installmentDb = JSON.parse(fs.readFileSync(installmentPath, 'utf8'))
  const selfDb = JSON.parse(fs.readFileSync(path, 'utf8'))

  if (genesisDb.requestsMade >= genesisDb.maxRequests) throw new Error('Maximum request limit has been reached')
  genesisDb.requestsMade++ // Increment it

  genesisDb = JSON.stringify(genesisDb) // Converts it back

  fs.writeFileSync(genesisPath, genesisDb, (err) => { // Returns it
    if (err) throw err
  })

  if (!(selfDb.root === undefined || selfDb.root.length == 0)) { // If the loan application exists
    if (!(nik in installmentDb)) installmentDb[nik] = {}
    installmentDb[nik][unixTimestamp] = []

    const selfDbRoot = selfDb.root.find(loanApps => loanApps.id == date)

    const timeRightNow = new Date()
    const structDatas = []
    const administrationFee = 100000 / duration
    const capital = selfDbRoot.amount / duration
    const total = capital + administrationFee

    for (let index = 1; index <= Number(duration); index++) {
      structDatas.push({
        dueDate: new Date(timeRightNow.getFullYear(), timeRightNow.getMonth() + index, timeRightNow.getDate()).toLocaleDateString(),
        administrationFee: Math.round(administrationFee), // Just the official rate from the app
        capital: Math.round(capital),
        total: Math.round(total)
      })

      installmentDb[nik][unixTimestamp].push({
        dueDate: new Date(timeRightNow.getFullYear(), timeRightNow.getMonth() + index, timeRightNow.getDate()).toLocaleDateString(),
        administrationFee: Math.round(administrationFee), // Just the official rate from the app
        capital: Math.round(capital),
        total: Math.round(total)
      })
    }

    installmentDb = JSON.stringify(installmentDb) // Convert it back to JSON

    fs.writeFileSync(installmentPath, installmentDb, (err) => { // Updates it
      if (err) throw err
    })

    return JSON.stringify(structDatas)
  } else {
    throw new Error("Loan application record not found. Make sure it is approved.")
  }
}

if (process.argv.length >= 3) console.table(JSON.parse(computeInstallment(process.argv[2], Number(process.argv[3]), process.argv[4])))

module.exports = computeInstallment