const fs = require('fs')

function getRejectedApplications(loanApplicationAmount, loanApplicationDate) {

  const genesisPath = `${process.cwd()}/db/${loanApplicationDate}.json`
  const path = `${process.cwd()}/db/rejected.json`

  let genesisDb = JSON.parse(fs.readFileSync(genesisPath, 'utf8'))
  const selfDb = JSON.parse(fs.readFileSync(path, 'utf8'))

  if (genesisDb.requestsMade >= genesisDb.maxRequests) throw new Error('Maximum request limit has been reached')
  genesisDb.requestsMade++ // Increment it

  genesisDb = JSON.stringify(genesisDb) // Converts it back

  fs.writeFileSync(genesisPath, genesisDb, (err) => { // Returns it
    if (err) throw err
  })

  try {
    let matchingNodes
    const selfDbRoot = selfDb.root.filter(loanApps => loanApps.amount == loanApplicationAmount)

    // If any nodes matches, it will be curated into an array. If not, set it to undefined.
    selfDbRoot === [] ? undefined : matchingNodes = selfDbRoot.map((object) => {
      return object.id
    }).join(' ')

    if (!(matchingNodes === undefined || matchingNodes.length == 0)) {
      console.log('Search result:', matchingNodes)
      return true
    } else {
      console.log('Sorry, unable to find it')
      return false
    }
  } catch (err) {
    if (err) throw new Error('Sorry, unable to find it')
  }

}

if (process.argv.length >= 3) console.log(getRejectedApplications(process.argv[2], process.argv[3]))

module.exports = getRejectedApplications