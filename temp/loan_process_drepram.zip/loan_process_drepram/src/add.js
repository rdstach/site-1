const fs = require('fs')

// Source: https://stackoverflow.com/a/21984136/10103199
// Would be used in validating the caller's age
function calculateAge(birthdate) {
  const ageDifMs = Date.now() - birthdate.getTime()
  const ageDate = new Date(ageDifMs) // miliseconds from epoch
  return Math.abs(ageDate.getUTCFullYear() - 1970)
}

function insertLoanApplication(nik, name, amount) {
  if (!(nik === 'undefined' || name === 'undefined' || isNaN(amount))) {
    nik = String(nik).match(/.{2}/g)
    const nikProvince = nik[0]
    const nikYear = (Number(nik[5]) <= 21 ? Number(`20${nik[5]}`) : Number(`19${nik[5]}`))
    const gender = (Number(nik[3]) > 40 ? 'female' : 'male') // Females birthdate's date are identified by having 40 added into it.
    const birthdate = new Date(nikYear, nik[4], nik[3]) // Format: year, month, day

    amount = Number(amount)

    /*
    "3174096112900001".match(/.{2}/g) => (8) ["31", "74", "09", "61", "12", "90", "00", "01"]

    [0]: Kode provinsi penduduk
    [1]: Kode kota/kabupaten penduduk
    [2]: Kode kecamatan penduduk
    [3]: Tanggal lahir penduduk
    [4]: Bulan lahir penduduk
    [5]: Tahun lahir penduduk (hanya 2 digit, perlu di convert jadi 4 digit)
    [6,7]: Kode urut penduduk (tidak dipakai)

    Year conversion: If the 2 digit is less than or equal to 21 (0-21, could be 2000 to 2021), it would be more likely to occur in the 21th century, obviously because most 1920s people has passed away. If the 2 digit is greater than 21 (22-99, could be 1922 to 1999).

    What we are doing is basically splitting a string into segments of character, since NIK have a fixed format.

    NIK Format: https://tutorlokal.com/en/extract-date-birth-nik-python/
    Source: https://stackoverflow.com/a/6259543/10103199
    */

    // Courtesy of https://stackoverflow.com/a/4929629/10103199
    let today = new Date()
    const day = String(today.getDate()).padStart(2, '0')
    const month = String(today.getMonth() + 1).padStart(2, '0') // January is 0
    const year = String(today.getFullYear()).slice(2) // Modification here, instead of using 4 digit years, we can just take the last 2 digit. Hence, the slice() method.

    today = day + month + year // Redefining the today variable with the necessary content

    const path = `${process.cwd()}/db/${today}.json`

    if (fs.existsSync(path)) {
      let todaysDb = JSON.parse(fs.readFileSync(path, 'utf8'))
      if (todaysDb.requestsMade >= todaysDb.maxRequests) throw new Error('Maximum request limit has been reached')
      // Automatically exits the program if the limit has been reached

      if (!('loanApplications' in todaysDb)) todaysDb.loanApplications = [] // Initiate property value
      const eligibleProvinces = [12, 31, 32, 35] // “DKI JAKARTA”, “JAWA BARAT”, “JAWA TIMUR”, and “SUMATERA UTARA”
      const personsOldness = calculateAge(birthdate)
      nik = nik.join('') // Rejoining the long array

      let status = { // Status of the loan application
        accepted: false,
        message: ''
      }

      if (!(amount <= 10000000 && amount >= 1000000)) status.message = 'Amount not eligible. Minimum is 1 million, maximum is 10 million'
      else if (!(personsOldness > 17 && personsOldness < 80)) status.message = 'Age is not eligible (greater than 17 / younger than 80)'
      else if (!(eligibleProvinces.includes(Number(nikProvince)))) status.message = 'Province not eligible' // Negation statement, because it acts if element is not included
      else status.accepted = true

      // For some unknown reasons, incrementing has some bugs when it comes to the first element, hence the special condition
      if (todaysDb.amountOfLoanApplications == 0) todaysDb.amountOfLoanApplications = 1
      else todaysDb.amountOfLoanApplications++, todaysDb.requestsMade++

      const loanApplicationId = `${today}${('0' + (todaysDb.amountOfLoanApplications)).slice(-2)}`

      // Taken from stackoverflow: how to turn single digits into two digits (https://stackoverflow.com/a/8043061/10103199)
      const loanApplicationNode = {
        id: loanApplicationId,
        applicant: {
          nik,
          name,
          gender,
          amount,
          status
        }
      }

      todaysDb.loanApplications.push(loanApplicationNode) // Appending the new node into the root object

      todaysDb = JSON.stringify(todaysDb) // Rewriting it into JSON

      fs.writeFileSync(path, todaysDb, (err) => {
        if (err) throw err
      })

      // The process above has finished writing to the main file, now it is time for the other more simple JSON files.
      // The computation below are going to write to either accepted or rejected's json file.

      let singleStatusFile, singleFilePath
      if (status.accepted) singleStatusFile = JSON.parse(fs.readFileSync(`${process.cwd()}/db/accepted.json`, 'utf8')), singleFilePath = `${process.cwd()}/db/accepted.json`
      else singleStatusFile = JSON.parse(fs.readFileSync(`${process.cwd()}/db/rejected.json`, 'utf8')), singleFilePath = `${process.cwd()}/db/rejected.json`

      if (!('root' in singleStatusFile)) singleStatusFile.root = []

      singleStatusFile.root.push({
        id: loanApplicationId,
        amount
      })

      singleStatusFile = JSON.stringify(singleStatusFile) // Rewriting it into JSON

      fs.writeFileSync(singleFilePath, singleStatusFile, (err) => {
        if (err) throw err
      })

      // After that is done, we will be recording all requests regardless of whether they are accepted or not below.

      let unifiedStatusFile, unifiedFilePath
      unifiedStatusFile = JSON.parse(fs.readFileSync(`${process.cwd()}/db/statuses.json`, 'utf8')), unifiedFilePath = `${process.cwd()}/db/statuses.json`

      if (!('root' in unifiedStatusFile)) unifiedStatusFile.root = []

      unifiedStatusFile.root.push({
        id: loanApplicationId,
        status: status.accepted
      })

      unifiedStatusFile = JSON.stringify(unifiedStatusFile) // Rewriting it into JSON

      fs.writeFileSync(unifiedFilePath, unifiedStatusFile, (err) => {
        if (err) throw err
      })

      return {
        id: loanApplicationId,
        message: `Loan application ${status.accepted ? 'accepted' : `rejected: ${status.message}`}`,
        accepted: status.accepted
      }
    } else {
      throw new Error('Today\'s database has not been initiated, please set the maximum requests before adding loan applications.')
    }
  }
}

// If there are more than two commmand arguments, we will call the function
if (process.argv.length >= 3) console.log(insertLoanApplication(process.argv[2], process.argv[3], process.argv[4]))

module.exports = insertLoanApplication