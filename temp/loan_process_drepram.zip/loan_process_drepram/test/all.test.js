const insert_loan_application = require(`../src/add.js`);
const create_day_max = require(`../src/create_day_max.js`);
const status = require(`../src/status.js`);
const installment = require(`../src/installment.js`);
const find_by_amount_accepted = require(`../src/find_by_amount_accepted.js`);
const find_by_amount_rejected = require(`../src/find_by_amount_rejected.js`);

let today = new Date()
const day = String(today.getDate()).padStart(2, '0')
const month = String(today.getMonth() + 1).padStart(2, '0') // January is 0
const year = String(today.getFullYear()).slice(2) // Modification here, instead of using 4 digit years, we can just take the last 2 digit. Hence, the slice() method.

today = day + month + year // Redefining the today variable with the necessary content

test('create initial file', () => { // Would not create because the file has to already exists before we run this script
  // expect(create_day_max("50")).not.toBe(`Unable to recreate file on same date. Maximum requests limit (50) for loan application has been set for today (${process.cwd()}/db/${today}.json)`);

  // It's supposed to be very simple with the code above but for some reasons, 
  // this section of the code seems to be conflicting with the other sections. 

  expect(create_day_max("50")).toBe(false); // Cannot initialize another file because it has to exist for all these tests to pass.
});

test('insert first loan application', () => {
  expect(insert_loan_application("3174096112900001", "Seseorang", "5000000").accepted).toBe(true);
});

test('insert second loan application', () => {
  expect(insert_loan_application("3172020903040069", "AndrePramaditya", "5000000").accepted).toBe(false);
  // This would not work because of the age in the NIK
});

test('get status of the first loan application', () => {
  expect(status(`${today}01`)).toBe(true);
});

test('plan installment', () => {
  expect(installment(`${today}01`, "3", "3174096112900001")).not.toBe("Loan application record not found. Make sure it is approved.");
});

test('get accepted loans with the amount of 5 million rupiah', () => {
  expect(find_by_amount_accepted(`5000000`, today)).toBe(true);
});

test('get rejected loans with the amount of 1 million rupiah', () => {
  expect(find_by_amount_rejected(`1000000`, today)).toBe(false); // Following the example responses
});